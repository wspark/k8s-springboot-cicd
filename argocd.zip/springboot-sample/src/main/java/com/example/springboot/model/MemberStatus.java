package com.example.springboot.model;

public enum MemberStatus {
    ACTIVE, DEACTIVATED
}