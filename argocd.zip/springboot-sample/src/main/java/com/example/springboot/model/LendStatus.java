package com.example.springboot.model;

public enum LendStatus {
    AVAILABLE, BURROWED
}